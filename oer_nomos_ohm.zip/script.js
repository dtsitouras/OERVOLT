
function calculateCurrent() {
    const voltage = document.getElementById('voltage').value;
    const resistance = document.getElementById('resistance').value;
    const current = (voltage / resistance).toFixed(2);
    document.getElementById('current').innerText = current;
}

function checkAnswer() {
    const answer = document.getElementById('answer').value;
    const correctAnswer = (120 / 60).toFixed(2);
    const feedback = document.getElementById('feedback');

    if (answer === correctAnswer) {
        feedback.innerText = "Σωστή Απάντηση!";
        feedback.style.color = "green";
    } else {
        feedback.innerText = "Λάθος Απάντηση. Προσπαθήστε ξανά!";
        feedback.style.color = "red";
    }
}
    